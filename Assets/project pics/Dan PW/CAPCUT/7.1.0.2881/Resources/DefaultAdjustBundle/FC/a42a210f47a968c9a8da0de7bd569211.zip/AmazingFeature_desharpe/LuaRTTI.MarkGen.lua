
TempScriptLua = TempScriptLua or {} ---@type TempScriptLua
TempScriptLua.__typename = "TempScriptLua"
TempScriptLua.__supername = "ScriptComponent"
TempScriptLua.__scriptname = ""
TempScriptLua.__scriptpath = ""

