
LumiManager = LumiManager or {} ---@type LumiManager
LumiManager.__typename = "LumiManager"
LumiManager.__supername = "ScriptComponent"
LumiManager.__scriptname = ""
LumiManager.__scriptpath = ""


LumiEffect = LumiEffect or {} ---@type LumiEffect
LumiEffect.__typename = "LumiEffect"
LumiEffect.__supername = "ScriptComponent"
LumiEffect.__scriptname = ""
LumiEffect.__scriptpath = ""


LumiSurfaceBlur = LumiSurfaceBlur or {} ---@type LumiSurfaceBlur
LumiSurfaceBlur.__typename = "LumiSurfaceBlur"
LumiSurfaceBlur.__supername = "ScriptComponent"
LumiSurfaceBlur.__scriptname = ""
LumiSurfaceBlur.__scriptpath = ""


LumiLayer = LumiLayer or {} ---@type LumiLayer
LumiLayer.__typename = "LumiLayer"
LumiLayer.__supername = "ScriptComponent"
LumiLayer.__scriptname = ""
LumiLayer.__scriptpath = ""


LumiUsmSharpen = LumiUsmSharpen or {} ---@type LumiUsmSharpen
LumiUsmSharpen.__typename = "LumiUsmSharpen"
LumiUsmSharpen.__supername = "ScriptComponent"
LumiUsmSharpen.__scriptname = ""
LumiUsmSharpen.__scriptpath = ""


ScriptCompStrongSharpen = ScriptCompStrongSharpen or {} ---@type ScriptCompStrongSharpen
ScriptCompStrongSharpen.__typename = "ScriptCompStrongSharpen"
ScriptCompStrongSharpen.__supername = "ScriptComponent"
ScriptCompStrongSharpen.__scriptname = ""
ScriptCompStrongSharpen.__scriptpath = ""

