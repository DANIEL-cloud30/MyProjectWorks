
SeekModeScript = SeekModeScript or {} ---@type SeekModeScript
SeekModeScript.__typename = "SeekModeScript"
SeekModeScript.__supername = "ScriptComponent"
SeekModeScript.__scriptname = ""
SeekModeScript.__scriptpath = ""

